const api = "https://age-of-empires-2-api.herokuapp.com/api/v1/";
const civilization_api = `${api}civilizations`;

let getCivilization = async() => {
  fetch(civilization_api,{mode:'cors'}).then(data=>data.json())
  .then(data=>{
       console.table(data);
  })
  return 1;
}
